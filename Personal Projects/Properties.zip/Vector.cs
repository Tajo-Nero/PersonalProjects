﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Personal_Projects
{
    struct Vector
    {
        public int x;
        public int y;
        public Vector(int inputX, int inputY)
        {
            x = inputX;
            y = inputY;
        }
    }
}
